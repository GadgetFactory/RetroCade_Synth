#include "stdint.h"

extern const uint8_t bitRevTable[256];
